from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import sqlite3
from statistics import median
from datetime import datetime
import random

app = Flask(__name__)
CORS(app)

DB_NAME = "llaqta_guardian.db"

# ==========================
# MEDIDAS REALES DEL PROTOTIPO
# ==========================

ALTURA_SENSOR_CM = 45.0
DISTANCIA_MIN_SENSOR_CM = 20.0
NIVEL_MAX_CONFIABLE_CM = ALTURA_SENSOR_CM - DISTANCIA_MIN_SENSOR_CM

UMBRAL_PREVENTIVO_CM = 10.0
UMBRAL_ALERTA_CM = 18.0
UMBRAL_CRITICO_CM = 23.0

HISTERESIS_CM = 1.5
VENTANA_FILTRO = 5
VENTANA_PREDICCION = 8

ALPHA_EMA = 0.35

MAX_SALTO_BRUSCO_CM = 6.0
VELOCIDAD_RAPIDA_CM_MIN = 0.8
VELOCIDAD_MUY_RAPIDA_CM_MIN = 1.5

INTERVALO_LECTURA_MIN = 1.0


# ==========================
# BASE DE DATOS
# ==========================

def conectar_db():
    return sqlite3.connect(DB_NAME)


def crear_tabla():
    conexion = conectar_db()
    cursor = conexion.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS mediciones (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fecha TEXT NOT NULL,
            modulo TEXT NOT NULL,

            distancia_sensor_agua_cm REAL,
            nivel_agua_cm REAL NOT NULL,
            nivel_filtrado_cm REAL,

            lluvia INTEGER NOT NULL,
            temperatura REAL,
            humedad REAL,
            bateria REAL,

            velocidad_subida REAL,
            prediccion_min REAL,
            r2_prediccion REAL,

            riesgo TEXT NOT NULL,
            puntaje_riesgo REAL,
            confianza REAL,

            anomalia INTEGER DEFAULT 0,
            sensor_saturado INTEGER DEFAULT 0,
            motivo TEXT
        )
    """)

    conexion.commit()
    conexion.close()

    asegurar_columnas()


def asegurar_columnas():
    columnas_necesarias = {
        "distancia_sensor_agua_cm": "REAL",
        "nivel_filtrado_cm": "REAL",
        "r2_prediccion": "REAL",
        "puntaje_riesgo": "REAL",
        "confianza": "REAL",
        "anomalia": "INTEGER DEFAULT 0",
        "sensor_saturado": "INTEGER DEFAULT 0",
        "motivo": "TEXT"
    }

    conexion = conectar_db()
    cursor = conexion.cursor()

    cursor.execute("PRAGMA table_info(mediciones)")
    columnas_actuales = [col[1] for col in cursor.fetchall()]

    for columna, tipo in columnas_necesarias.items():
        if columna not in columnas_actuales:
            cursor.execute(f"ALTER TABLE mediciones ADD COLUMN {columna} {tipo}")

    conexion.commit()
    conexion.close()


def obtener_historial(modulo="LG-01", limite=30):
    conexion = conectar_db()
    cursor = conexion.cursor()

    cursor.execute("""
        SELECT id, fecha, modulo,
               distancia_sensor_agua_cm,
               nivel_agua_cm,
               nivel_filtrado_cm,
               lluvia,
               temperatura,
               humedad,
               bateria,
               velocidad_subida,
               prediccion_min,
               r2_prediccion,
               riesgo,
               puntaje_riesgo,
               confianza,
               anomalia,
               sensor_saturado,
               motivo
        FROM mediciones
        WHERE modulo = ?
        ORDER BY id DESC
        LIMIT ?
    """, (modulo, limite))

    filas = cursor.fetchall()
    conexion.close()

    datos = []

    for fila in reversed(filas):
        datos.append({
            "id": fila[0],
            "fecha": fila[1],
            "modulo": fila[2],
            "distancia_sensor_agua_cm": fila[3],
            "nivel_agua_cm": fila[4],
            "nivel_filtrado_cm": fila[5],
            "lluvia": fila[6],
            "temperatura": fila[7],
            "humedad": fila[8],
            "bateria": fila[9],
            "velocidad_subida": fila[10],
            "prediccion_min": fila[11],
            "r2_prediccion": fila[12],
            "riesgo": fila[13],
            "puntaje_riesgo": fila[14],
            "confianza": fila[15],
            "anomalia": fila[16],
            "sensor_saturado": fila[17],
            "motivo": fila[18]
        })

    return datos


def obtener_ultima_medicion(modulo="LG-01"):
    historial = obtener_historial(modulo, 1)
    return historial[-1] if historial else None


# ==========================
# CONVERSIÓN DISTANCIA A NIVEL
# ==========================

def convertir_distancia_a_nivel(distancia_cm, historial):
    anomalia = 0
    sensor_saturado = 0
    motivos = []

    if distancia_cm is None:
        anomalia = 1
        motivos.append("No se recibió distancia del sensor ultrasónico.")

        ultima = historial[-1] if historial else None
        if ultima and ultima["nivel_filtrado_cm"] is not None:
            nivel = ultima["nivel_filtrado_cm"]
        else:
            nivel = 0

        return nivel, anomalia, sensor_saturado, motivos

    distancia_cm = float(distancia_cm)

    if distancia_cm <= 0:
        sensor_saturado = 1
        motivos.append("Lectura sin eco o distancia 0. Se asume condición crítica por seguridad.")
        return NIVEL_MAX_CONFIABLE_CM, anomalia, sensor_saturado, motivos

    if distancia_cm <= DISTANCIA_MIN_SENSOR_CM:
        sensor_saturado = 1
        motivos.append("El agua está a 20 cm o menos del sensor. Se alcanzó la zona muerta.")
        return NIVEL_MAX_CONFIABLE_CM, anomalia, sensor_saturado, motivos

    if distancia_cm > 60:
        anomalia = 1
        motivos.append("Distancia fuera del rango físico esperado del prototipo.")

        ultima = historial[-1] if historial else None
        if ultima and ultima["nivel_filtrado_cm"] is not None:
            nivel = ultima["nivel_filtrado_cm"]
        else:
            nivel = 0

        return nivel, anomalia, sensor_saturado, motivos

    nivel = ALTURA_SENSOR_CM - distancia_cm

    if nivel < 0:
        nivel = 0

    if nivel > NIVEL_MAX_CONFIABLE_CM:
        nivel = NIVEL_MAX_CONFIABLE_CM

    return round(nivel, 2), anomalia, sensor_saturado, motivos


# ==========================
# FILTRO ANTIFALSAS ALARMAS
# ==========================

def filtrar_nivel(nivel_actual, historial, lluvia, sensor_saturado):
    if sensor_saturado:
        return NIVEL_MAX_CONFIABLE_CM, 0, ["Nivel fijado al máximo confiable por saturación del sensor."]

    motivos = []
    anomalia = 0

    niveles = []

    for dato in historial[-(VENTANA_FILTRO - 1):]:
        nivel = dato["nivel_filtrado_cm"]

        if nivel is None:
            nivel = dato["nivel_agua_cm"]

        niveles.append(float(nivel))

    niveles.append(float(nivel_actual))

    nivel_mediana = median(niveles)

    if not historial:
        return round(nivel_mediana, 2), anomalia, motivos

    ultima = historial[-1]

    nivel_anterior = ultima["nivel_agua_cm"]
    nivel_filtrado_anterior = ultima["nivel_filtrado_cm"]

    if nivel_filtrado_anterior is None:
        nivel_filtrado_anterior = nivel_anterior

    salto = abs(nivel_actual - nivel_anterior)

    if salto > MAX_SALTO_BRUSCO_CM and lluvia == 0:
        anomalia = 1
        motivos.append("Salto brusco sin lluvia. Se suaviza la lectura para evitar falsa alarma.")
        nivel_suavizado = nivel_filtrado_anterior
    else:
        nivel_suavizado = (ALPHA_EMA * nivel_mediana) + ((1 - ALPHA_EMA) * nivel_filtrado_anterior)

    return round(nivel_suavizado, 2), anomalia, motivos


# ==========================
# PREDICCIÓN
# ==========================

def calcular_regresion_lineal(historial, nivel_actual_filtrado):
    niveles = []

    for dato in historial[-VENTANA_PREDICCION:]:
        nivel = dato["nivel_filtrado_cm"]

        if nivel is None:
            nivel = dato["nivel_agua_cm"]

        niveles.append(float(nivel))

    niveles.append(float(nivel_actual_filtrado))

    if len(niveles) < 3:
        return 0, None, 0

    x = [i * INTERVALO_LECTURA_MIN for i in range(len(niveles))]
    y = niveles

    promedio_x = sum(x) / len(x)
    promedio_y = sum(y) / len(y)

    numerador = sum((x[i] - promedio_x) * (y[i] - promedio_y) for i in range(len(x)))
    denominador = sum((x[i] - promedio_x) ** 2 for i in range(len(x)))

    if denominador == 0:
        return 0, None, 0

    pendiente = numerador / denominador
    intercepto = promedio_y - pendiente * promedio_x

    y_pred = [pendiente * xi + intercepto for xi in x]

    ss_res = sum((y[i] - y_pred[i]) ** 2 for i in range(len(y)))
    ss_tot = sum((yi - promedio_y) ** 2 for yi in y)

    if ss_tot == 0:
        r2 = 0
    else:
        r2 = 1 - (ss_res / ss_tot)

    r2 = max(0, min(1, r2))

    if pendiente <= 0.05:
        return round(pendiente, 2), None, round(r2, 2)

    falta = UMBRAL_CRITICO_CM - nivel_actual_filtrado

    if falta <= 0:
        prediccion = 0
    else:
        prediccion = falta / pendiente

    return round(pendiente, 2), round(prediccion, 1), round(r2, 2)


# ==========================
# MODELO DE RIESGO
# ==========================

def contar_consecutivos(historial, condicion):
    contador = 0

    for dato in reversed(historial):
        if condicion(dato):
            contador += 1
        else:
            break

    return contador


def evaluar_riesgo(nivel, lluvia, velocidad, prediccion_min, r2, historial, sensor_saturado, anomalia):
    motivos = []
    puntaje = 0

    if sensor_saturado:
        return "CRITICO", 100, ["Riesgo crítico: el agua llegó a la zona muerta del sensor ultrasónico."]

    if nivel >= UMBRAL_CRITICO_CM:
        puntaje += 70
        motivos.append("Nivel del agua en zona crítica.")
    elif nivel >= UMBRAL_ALERTA_CM:
        puntaje += 50
        motivos.append("Nivel del agua en zona de alerta.")
    elif nivel >= UMBRAL_PREVENTIVO_CM:
        puntaje += 30
        motivos.append("Nivel del agua en zona preventiva.")
    else:
        puntaje += 10
        motivos.append("Nivel del agua dentro del rango normal.")

    if lluvia == 1:
        puntaje += 15
        motivos.append("Se detectó lluvia.")

    if velocidad >= VELOCIDAD_MUY_RAPIDA_CM_MIN:
        puntaje += 25
        motivos.append("El nivel está subiendo muy rápido.")
    elif velocidad >= VELOCIDAD_RAPIDA_CM_MIN:
        puntaje += 15
        motivos.append("El nivel está subiendo rápido.")
    elif velocidad > 0.2:
        puntaje += 8
        motivos.append("El nivel presenta tendencia de subida.")

    if prediccion_min is not None:
        if prediccion_min <= 5 and r2 >= 0.30:
            puntaje += 25
            motivos.append("La predicción indica llegada rápida al umbral crítico.")
        elif prediccion_min <= 10 and r2 >= 0.25:
            puntaje += 15
            motivos.append("La predicción indica posible riesgo en corto tiempo.")
        elif prediccion_min <= 20 and r2 >= 0.20:
            puntaje += 8
            motivos.append("La predicción recomienda vigilancia preventiva.")

    if anomalia:
        puntaje -= 10
        motivos.append("Se detectó una anomalía. Se reduce la confianza de la decisión.")

    puntaje = max(0, min(100, puntaje))

    if puntaje >= 85:
        riesgo = "CRITICO"
    elif puntaje >= 60:
        riesgo = "ALERTA"
    elif puntaje >= 35:
        riesgo = "PREVENTIVO"
    else:
        riesgo = "NORMAL"

    consecutivos_alerta = contar_consecutivos(
        historial,
        lambda d: (d["nivel_filtrado_cm"] if d["nivel_filtrado_cm"] is not None else d["nivel_agua_cm"]) >= UMBRAL_ALERTA_CM - HISTERESIS_CM
    )

    consecutivos_critico = contar_consecutivos(
        historial,
        lambda d: (d["nivel_filtrado_cm"] if d["nivel_filtrado_cm"] is not None else d["nivel_agua_cm"]) >= UMBRAL_CRITICO_CM - HISTERESIS_CM
    )

    if riesgo == "CRITICO":
        if nivel >= UMBRAL_CRITICO_CM or consecutivos_critico >= 2:
            riesgo = "CRITICO"
        else:
            riesgo = "ALERTA"
            motivos.append("Crítico aún no confirmado por lecturas consecutivas.")

    if riesgo == "ALERTA":
        if nivel >= UMBRAL_ALERTA_CM or consecutivos_alerta >= 2 or (lluvia == 1 and velocidad > 0.5):
            riesgo = "ALERTA"
        else:
            riesgo = "PREVENTIVO"
            motivos.append("Alerta aún no confirmada por lecturas consecutivas.")

    if historial:
        riesgo_anterior = historial[-1]["riesgo"]

        if riesgo_anterior == "CRITICO" and nivel >= UMBRAL_CRITICO_CM - HISTERESIS_CM:
            riesgo = "CRITICO"
            motivos.append("Histéresis activa: se mantiene crítico por seguridad.")

        elif riesgo_anterior == "ALERTA" and nivel >= UMBRAL_ALERTA_CM - HISTERESIS_CM:
            if riesgo == "NORMAL":
                riesgo = "PREVENTIVO"
            motivos.append("Histéresis activa: se evita bajar bruscamente a normal.")

    return riesgo, puntaje, motivos


def calcular_confianza(riesgo, lluvia, velocidad, r2, anomalia, sensor_saturado):
    confianza = 65

    if r2 >= 0.70:
        confianza += 15
    elif r2 >= 0.40:
        confianza += 8

    if lluvia == 1 and velocidad > 0:
        confianza += 8

    if riesgo in ["ALERTA", "CRITICO"] and velocidad > 0:
        confianza += 8

    if sensor_saturado:
        confianza -= 10

    if anomalia:
        confianza -= 25

    return max(0, min(100, round(confianza, 1)))


# ==========================
# RUTAS
# ==========================

@app.route("/")
def inicio():
    return render_template("index2.html")


@app.route("/api/config", methods=["GET"])
def config():
    return jsonify({
        "altura_sensor_cm": ALTURA_SENSOR_CM,
        "distancia_min_sensor_cm": DISTANCIA_MIN_SENSOR_CM,
        "nivel_max_confiable_cm": NIVEL_MAX_CONFIABLE_CM,
        "umbral_preventivo_cm": UMBRAL_PREVENTIVO_CM,
        "umbral_alerta_cm": UMBRAL_ALERTA_CM,
        "umbral_critico_cm": UMBRAL_CRITICO_CM
    })


@app.route("/api/medicion", methods=["POST"])
def recibir_medicion():
    datos = request.get_json()

    if not datos:
        return jsonify({"error": "No se recibió JSON"}), 400

    modulo = datos.get("modulo", "LG-01")
    historial = obtener_historial(modulo, 30)

    distancia = datos.get("distancia_sensor_agua_cm")

    if distancia is None and "nivel_agua_cm" in datos:
        nivel_recibido = float(datos.get("nivel_agua_cm"))
        distancia = ALTURA_SENSOR_CM - nivel_recibido

    lluvia = int(datos.get("lluvia", 0))
    temperatura = datos.get("temperatura")
    humedad = datos.get("humedad")
    bateria = datos.get("bateria")

    nivel_calculado, anomalia_conversion, sensor_saturado, motivos_conversion = convertir_distancia_a_nivel(
        distancia,
        historial
    )

    nivel_filtrado, anomalia_filtro, motivos_filtro = filtrar_nivel(
        nivel_calculado,
        historial,
        lluvia,
        sensor_saturado
    )

    anomalia = 1 if anomalia_conversion or anomalia_filtro else 0

    velocidad, prediccion_min, r2 = calcular_regresion_lineal(
        historial,
        nivel_filtrado
    )

    riesgo, puntaje, motivos_riesgo = evaluar_riesgo(
        nivel_filtrado,
        lluvia,
        velocidad,
        prediccion_min,
        r2,
        historial,
        sensor_saturado,
        anomalia
    )

    confianza = calcular_confianza(
        riesgo,
        lluvia,
        velocidad,
        r2,
        anomalia,
        sensor_saturado
    )

    motivos = motivos_conversion + motivos_filtro + motivos_riesgo
    motivo_texto = " | ".join(motivos)

    fecha = datetime.now().isoformat(timespec="seconds")

    conexion = conectar_db()
    cursor = conexion.cursor()

    cursor.execute("""
        INSERT INTO mediciones (
            fecha, modulo,
            distancia_sensor_agua_cm,
            nivel_agua_cm,
            nivel_filtrado_cm,
            lluvia,
            temperatura,
            humedad,
            bateria,
            velocidad_subida,
            prediccion_min,
            r2_prediccion,
            riesgo,
            puntaje_riesgo,
            confianza,
            anomalia,
            sensor_saturado,
            motivo
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        fecha,
        modulo,
        distancia,
        nivel_calculado,
        nivel_filtrado,
        lluvia,
        temperatura,
        humedad,
        bateria,
        velocidad,
        prediccion_min,
        r2,
        riesgo,
        puntaje,
        confianza,
        anomalia,
        sensor_saturado,
        motivo_texto
    ))

    conexion.commit()
    conexion.close()

    return jsonify({
        "mensaje": "Medición guardada correctamente",
        "fecha": fecha,
        "modulo": modulo,
        "distancia_sensor_agua_cm": distancia,
        "nivel_agua_cm": nivel_calculado,
        "nivel_filtrado_cm": nivel_filtrado,
        "lluvia": lluvia,
        "temperatura": temperatura,
        "humedad": humedad,
        "bateria": bateria,
        "velocidad_subida": velocidad,
        "prediccion_min": prediccion_min,
        "r2_prediccion": r2,
        "riesgo": riesgo,
        "puntaje_riesgo": puntaje,
        "confianza": confianza,
        "anomalia": anomalia,
        "sensor_saturado": sensor_saturado,
        "motivo": motivo_texto
    })


@app.route("/api/ultimas", methods=["GET"])
def ultimas_mediciones():
    limite = int(request.args.get("limite", 30))
    modulo = request.args.get("modulo", "LG-01")

    historial = obtener_historial(modulo, limite)

    return jsonify(list(reversed(historial)))


@app.route("/api/simular", methods=["POST"])
def simular_medicion():
    modulo = "LG-01"
    ultima = obtener_ultima_medicion(modulo)

    if ultima and ultima["distancia_sensor_agua_cm"] is not None:
        distancia_base = float(ultima["distancia_sensor_agua_cm"])
    else:
        distancia_base = 45.0

    lluvia = random.choices([0, 1], weights=[55, 45])[0]

    if lluvia == 1:
        cambio_distancia = random.uniform(-2.8, -0.4)
    else:
        cambio_distancia = random.uniform(-0.6, 1.0)

    distancia_nueva = distancia_base + cambio_distancia

    if random.random() < 0.06:
        distancia_nueva += random.choice([-10, 10, 25])

    distancia_nueva = max(0, min(70, distancia_nueva))

    datos_simulados = {
        "modulo": modulo,
        "distancia_sensor_agua_cm": round(distancia_nueva, 2),
        "lluvia": lluvia,
        "temperatura": round(random.uniform(25, 33), 1),
        "humedad": round(random.uniform(76, 98), 1),
        "bateria": round(random.uniform(10.8, 12.7), 2)
    }

    with app.test_request_context(json=datos_simulados):
        return recibir_medicion()


@app.route("/api/reiniciar", methods=["POST"])
def reiniciar_datos():
    conexion = conectar_db()
    cursor = conexion.cursor()
    cursor.execute("DELETE FROM mediciones")
    conexion.commit()
    conexion.close()

    return jsonify({"mensaje": "Datos reiniciados correctamente"})


if __name__ == "__main__":
    crear_tabla()
    app.run(host="0.0.0.0", port=5000, debug=True)