#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <DHT.h>

// ======================================================
// WIFI Y SERVIDOR FLASK
// ======================================================

const char* WIFI_SSID = "motorola edge 40_2257";
const char* WIFI_PASSWORD = "AmoaBTS321";

// IP actual de tu laptop donde corre Flask
const char* SERVER_URL = "http://10.255.118.127:5000/api/medicion";

// ======================================================
// PINES DEL HARDWARE
// ======================================================

#define LED_PIN 14

#define TRIG_PIN 5
#define ECHO_PIN 18

#define DHT_PIN 4
#define DHTTYPE DHT22

#define RAIN_PIN 19

#define MP3_RX 17
#define MP3_TX 16

// ======================================================
// MEDIDAS REALES DEL PROTOTIPO
// ======================================================

const float ALTURA_SENSOR_CM = 45.0;
const float DISTANCIA_MIN_SENSOR_CM = 20.0;

const float UMBRAL_PREVENTIVO_CM = 10.0;
const float UMBRAL_ALERTA_CM = 18.0;
const float UMBRAL_CRITICO_CM = 23.0;

// En el sensor FC-37 normalmente:
// LOW = lluvia detectada
// HIGH = seco
const bool RAIN_ACTIVE_LOW = true;

// Cada cuánto se envían datos al dashboard
const unsigned long INTERVALO_ENVIO_MS = 5000;

// ======================================================
// OBJETOS
// ======================================================

DHT dht(DHT_PIN, DHTTYPE);
HardwareSerial mp3(1);

// ======================================================
// VARIABLES GLOBALES
// ======================================================

unsigned long ultimoEnvio = 0;
unsigned long ultimoParpadeo = 0;
unsigned long ultimoAudio = 0;

bool estadoLed = false;

String riesgoActual = "NORMAL";
String ultimoRiesgoAudio = "";

// ======================================================
// CONTROL DEL MP3
// ======================================================

void sendCommand(uint8_t cmd, uint8_t param1 = 0, uint8_t param2 = 0) {
  uint8_t buffer[10] = {
    0x7E, 0xFF, 0x06, cmd, 0x00, param1, param2, 0xFE, 0xEF, 0xEF
  };

  uint16_t sum = 0;

  for (int i = 1; i < 7; i++) {
    sum += buffer[i];
  }

  sum = 0 - sum;

  buffer[7] = (sum >> 8) & 0xFF;
  buffer[8] = sum & 0xFF;

  mp3.write(buffer, 10);
}

void reproducirPista(int pista) {
  unsigned long ahora = millis();

  // Evita repetir audio demasiado rápido
  if (ahora - ultimoAudio < 10000) {
    return;
  }

  sendCommand(0x0F, 0, pista);
  ultimoAudio = ahora;
}

void iniciarMP3() {
  mp3.begin(9600, SERIAL_8N1, MP3_RX, MP3_TX);

  delay(500);

  sendCommand(0x09);        // Seleccionar tarjeta TF
  delay(500);

  sendCommand(0x06, 0, 15); // Volumen 15 de 30
  delay(500);

  Serial.println("MP3 inicializado");
}

// ======================================================
// WIFI
// ======================================================

void conectarWiFi() {
  Serial.println();
  Serial.print("Conectando a WiFi: ");
  Serial.println(WIFI_SSID);

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  int intentos = 0;

  while (WiFi.status() != WL_CONNECTED && intentos < 40) {
    delay(500);
    Serial.print(".");
    intentos++;
  }

  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("WiFi conectado correctamente");
    Serial.print("IP del ESP32: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("No se pudo conectar al WiFi");
  }
}

void verificarWiFi() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi desconectado. Reintentando...");
    WiFi.disconnect();
    delay(500);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  }
}

// ======================================================
// LECTURA DEL ULTRASÓNICO
// Igual al estilo de tu código antiguo
// ======================================================

float medirDistanciaUltrasonico() {
  long duration;
  float distance;

  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);

  digitalWrite(TRIG_PIN, LOW);

  // Sin timeout corto para que funcione como tu código antiguo
  duration = pulseIn(ECHO_PIN, HIGH);

  if (duration == 0) {
    return -1;
  }

  distance = duration * 0.034 / 2.0;

  if (distance <= 0 || distance > 100) {
    return -1;
  }

  return distance;
}

// ======================================================
// CÁLCULO LOCAL DE RESPALDO
// ======================================================

float calcularNivelLocal(float distanciaCm) {
  if (distanciaCm <= 0) {
    return 0;
  }

  if (distanciaCm <= DISTANCIA_MIN_SENSOR_CM) {
    return ALTURA_SENSOR_CM - DISTANCIA_MIN_SENSOR_CM;
  }

  float nivel = ALTURA_SENSOR_CM - distanciaCm;

  if (nivel < 0) {
    nivel = 0;
  }

  if (nivel > 25) {
    nivel = 25;
  }

  return nivel;
}

String calcularRiesgoLocal(float distanciaCm, bool lluvia) {
  if (distanciaCm <= 0) {
    return "NORMAL";
  }

  if (distanciaCm <= DISTANCIA_MIN_SENSOR_CM) {
    return "CRITICO";
  }

  float nivel = calcularNivelLocal(distanciaCm);

  if (nivel >= UMBRAL_CRITICO_CM) {
    return "CRITICO";
  }

  if (nivel >= UMBRAL_ALERTA_CM) {
    return "ALERTA";
  }

  if (nivel >= UMBRAL_PREVENTIVO_CM || lluvia) {
    return "PREVENTIVO";
  }

  return "NORMAL";
}

// ======================================================
// ALERTAS LOCALES
// ======================================================

void actualizarLed() {
  unsigned long ahora = millis();
  unsigned long intervalo = 1000;

  if (riesgoActual == "NORMAL") {
    digitalWrite(LED_PIN, LOW);
    return;
  }

  if (riesgoActual == "PREVENTIVO") {
    intervalo = 900;
  } else if (riesgoActual == "ALERTA") {
    intervalo = 350;
  } else if (riesgoActual == "CRITICO") {
    intervalo = 120;
  }

  if (ahora - ultimoParpadeo >= intervalo) {
    ultimoParpadeo = ahora;
    estadoLed = !estadoLed;
    digitalWrite(LED_PIN, estadoLed);
  }
}

void actualizarAudio(String riesgo) {
  if (riesgo == ultimoRiesgoAudio) {
    return;
  }

  if (riesgo == "PREVENTIVO") {
    reproducirPista(1);
  } else if (riesgo == "ALERTA") {
    reproducirPista(2);
  } else if (riesgo == "CRITICO") {
    reproducirPista(3);
  }

  ultimoRiesgoAudio = riesgo;
}

// ======================================================
// ENVÍO DE DATOS A FLASK
// ======================================================

void enviarDatosServidor(float distanciaCm, bool lluviaDetectada, float temperatura, float humedad) {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("No hay WiFi. Se usa riesgo local.");
    riesgoActual = calcularRiesgoLocal(distanciaCm, lluviaDetectada);
    actualizarAudio(riesgoActual);
    return;
  }

  // Si el ultrasónico falló, NO se manda distancia 0.
  // Así evitamos falsos críticos.
  if (distanciaCm <= 0) {
    Serial.println("No se envía a Flask porque la distancia ultrasónica no es válida.");
    return;
  }

  HTTPClient http;

  http.begin(SERVER_URL);
  http.addHeader("Content-Type", "application/json");

  StaticJsonDocument<256> doc;

  doc["modulo"] = "LG-01";
  doc["distancia_sensor_agua_cm"] = distanciaCm;
  doc["lluvia"] = lluviaDetectada ? 1 : 0;

  if (!isnan(temperatura)) {
    doc["temperatura"] = temperatura;
  } else {
    doc["temperatura"] = nullptr;
  }

  if (!isnan(humedad)) {
    doc["humedad"] = humedad;
  } else {
    doc["humedad"] = nullptr;
  }

  String json;
  serializeJson(doc, json);

  Serial.println();
  Serial.println("Enviando JSON a Flask:");
  Serial.println(json);

  int codigoHTTP = http.POST(json);

  Serial.print("Código HTTP: ");
  Serial.println(codigoHTTP);

  if (codigoHTTP > 0) {
    String respuesta = http.getString();

    Serial.println("Respuesta del servidor:");
    Serial.println(respuesta);

    StaticJsonDocument<768> respuestaDoc;
    DeserializationError error = deserializeJson(respuestaDoc, respuesta);

    if (!error) {
      const char* riesgoServidor = respuestaDoc["riesgo"];

      if (riesgoServidor != nullptr) {
        riesgoActual = String(riesgoServidor);
      } else {
        riesgoActual = calcularRiesgoLocal(distanciaCm, lluviaDetectada);
      }

      float nivel = respuestaDoc["nivel_agua_cm"] | -1;
      float nivelFiltrado = respuestaDoc["nivel_filtrado_cm"] | -1;
      float confianza = respuestaDoc["confianza"] | -1;
      float prediccion = respuestaDoc["prediccion_min"] | -1;

      Serial.println("----- RESULTADO DEL MODELO -----");
      Serial.print("Riesgo: ");
      Serial.println(riesgoActual);

      Serial.print("Nivel calculado: ");
      Serial.print(nivel);
      Serial.println(" cm");

      Serial.print("Nivel filtrado: ");
      Serial.print(nivelFiltrado);
      Serial.println(" cm");

      Serial.print("Confianza: ");
      Serial.print(confianza);
      Serial.println(" %");

      Serial.print("Predicción: ");
      Serial.print(prediccion);
      Serial.println(" min");
      Serial.println("--------------------------------");

      actualizarAudio(riesgoActual);

    } else {
      Serial.println("No se pudo leer respuesta JSON. Se usa riesgo local.");
      riesgoActual = calcularRiesgoLocal(distanciaCm, lluviaDetectada);
      actualizarAudio(riesgoActual);
    }

  } else {
    Serial.println("Error enviando datos al servidor Flask.");
    riesgoActual = calcularRiesgoLocal(distanciaCm, lluviaDetectada);
    actualizarAudio(riesgoActual);
  }

  http.end();
}

// ======================================================
// SETUP
// ======================================================

void setup() {
  Serial.begin(115200);

  pinMode(LED_PIN, OUTPUT);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(RAIN_PIN, INPUT);

  digitalWrite(LED_PIN, LOW);

  dht.begin();

  iniciarMP3();

  conectarWiFi();

  Serial.println();
  Serial.println("Sistema Llaqta Guardian iniciado");
  Serial.println("--------------------------------");
}

// ======================================================
// LOOP PRINCIPAL
// ======================================================

void loop() {
  verificarWiFi();
  actualizarLed();

  unsigned long ahora = millis();

  if (ahora - ultimoEnvio >= INTERVALO_ENVIO_MS) {
    ultimoEnvio = ahora;

    // Pequeña pausa para estabilizar sensores
    delay(200);

    // --- Sensor ultrasónico ---
    float distancia = medirDistanciaUltrasonico();

    // --- DHT22 ---
    float temperatura = dht.readTemperature();
    float humedad = dht.readHumidity();

    // --- Sensor lluvia ---
    int lecturaLluvia = digitalRead(RAIN_PIN);

    bool lluviaDetectada;

    if (RAIN_ACTIVE_LOW) {
      lluviaDetectada = (lecturaLluvia == LOW);
    } else {
      lluviaDetectada = (lecturaLluvia == HIGH);
    }

    Serial.println();
    Serial.println("========== LECTURA LOCAL ==========");

    if (distancia > 0) {
      Serial.print("Distancia sensor-agua: ");
      Serial.print(distancia);
      Serial.println(" cm");

      float nivelLocal = calcularNivelLocal(distancia);

      Serial.print("Nivel local calculado: ");
      Serial.print(nivelLocal);
      Serial.println(" cm");

      if (distancia <= DISTANCIA_MIN_SENSOR_CM) {
        Serial.println("Zona muerta alcanzada: distancia menor o igual a 20 cm");
      }

    } else {
      Serial.println("Error: no se obtuvo lectura válida del ultrasónico");
    }

    if (!isnan(temperatura) && !isnan(humedad)) {
      Serial.print("Temperatura: ");
      Serial.print(temperatura);
      Serial.println(" °C");

      Serial.print("Humedad: ");
      Serial.print(humedad);
      Serial.println(" %");
    } else {
      Serial.println("Error leyendo DHT22");
    }

    Serial.print("Sensor lluvia digital: ");
    Serial.println(lecturaLluvia);

    Serial.print("Lluvia detectada: ");
    Serial.println(lluviaDetectada ? "SI" : "NO");

    Serial.println("===================================");

    enviarDatosServidor(distancia, lluviaDetectada, temperatura, humedad);
  }
}
